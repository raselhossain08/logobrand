<script setup>
import HeaderPage from '@/components/HeaderPage.vue'
import BannerContent from '@/components/BannerContent.vue'
import PageContent from '@/components/PageContent.vue'
</script>

<template>
  <main>
    <HeaderPage />
    <BannerContent />
    <PageContent /> 
  </main>
</template>
