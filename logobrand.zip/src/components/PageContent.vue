<template>
  <div class="page-content">
    <div class="container py-10 relative">
      <div class="quick-access p-5">
        <h1>Acceso Rapido</h1>
        <div class="flex flex-wrap">
          <div class="w-4/12 py-4">
            <div class="quick-box flex items-center">
              <img src="@/assets/arrow.png" alt="arrow" />
              <a href="" class="ml-3">Secretaría del Acuerdo de Escazú</a>
            </div>
          </div>
          <div class="w-4/12 py-4">
            <div class="quick-box flex items-center">
              <img src="@/assets/arrow.png" alt="arrow" />
              <a href="" class="ml-3">Implementacion legal en mexico</a>
            </div>
          </div>
          <div class="w-4/12 py-4">
            <div class="quick-box flex items-center">
              <img src="@/assets/arrow.png" alt="arrow" />
              <a href="" class="ml-3">Secretaría del Acuerdo de Escazú</a>
            </div>
          </div>
          <div class="w-4/12 py-4">
            <div class="quick-box flex items-center">
              <img src="@/assets/arrow.png" alt="arrow" />
              <a href="" class="ml-3">Recursos multimedia y otros materiales</a>
            </div>
          </div>
          <div class="w-4/12 py-4">
            <div class="quick-box flex items-center">
              <img src="@/assets/arrow.png" alt="arrow" />
              <a href="" class="ml-3">Secretaría del Acuerdo de Escazú</a>
            </div>
          </div>
          <div class="w-4/12 py-4">
            <div class="quick-box flex items-center">
              <img src="@/assets/arrow.png" alt="arrow" />
              <a href="" class="ml-3">Secretaría del Acuerdo de Escazú</a>
            </div>
          </div>
        </div>
      </div>
      <button type="button" class="absolute flex justify-center items-center quick-button">
        <img src="@/assets/arrowRight.png" alt="arrowRight" class="mr-2">
        INICIAR SESION 
      </button>
    </div>
    <div class="container">
      <div class="flex w-full">
        <div class="w-8/12 overflow-y-auto page-content-box ">
          <PostContent />
          <PostContent  class="py-10"/>
        </div>
        <div class="w-4/12 pl-8">
          <SidebarContent />
        </div>
      </div>
    </div>
  </div>
</template>

<style>
.page-content {
  background: #e6e6e6;
}
.quick-access {
  background: #fff;
  border-radius: 10px;
}
.quick-access h1 {
  font-family: 'Public Sans', sans-serif;
  font-size: 32px;
  font-weight: 700;
  line-height: 37.6px;
  text-align: left;
  color: #141e0c;
}
.page-content-box{
    height: 130vh;
}
.page-content-box::-webkit-scrollbar{
    display: none;
}
.quick-access a {
  font-family: 'Public Sans', sans-serif;
  font-size: 17px;
  font-weight: 700;
  line-height: 37.6px;
  text-align: left;
  color: #4f5da3;
  text-decoration: underline;
}
.quick-button{
    top: 77px;
    right: -169px;
    font-family: "Public Sans",sans-serif;
    font-size: 16px;
    font-weight: 700;
    line-height: 18.8px;
    letter-spacing: -0.02em;
    text-align: left;
    color: #6E851C;
}
</style>

<script>
import PostContent from '@/components/PostContent.vue'
import SidebarContent from '@/components/SidebarContent.vue'
export default {
  components: {
    PostContent,
    SidebarContent
  }
}
</script>
