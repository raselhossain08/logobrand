<template>
    <div>
        <div class="post-items">
            <button type="button">
                <font-awesome-icon :icon="['fas', 'ellipsis']" />
            </button>
        </div>
    </div>
</template>