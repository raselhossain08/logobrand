
<template>
    <div class="page-content">
         <div class="container py-10">
                <div class="quick-access p-5">
                <h1>Acceso Rapido</h1>
                <div class="flex flex-wrap">
                    <div class="w-4/12 py-4">
                        <div class="quick-box flex items-center">
                            <img src="@/assets/arrow.png" alt="arrow">
                            <a href="" class="ml-3">Secretaría del Acuerdo de Escazú</a>
                        </div>
                    </div>
                    <div class="w-4/12 py-4">
                        <div class="quick-box flex items-center">
                            <img src="@/assets/arrow.png" alt="arrow">
                            <a href="" class="ml-3">Implementacion legal en mexico</a>
                        </div>
                    </div>
                    <div class="w-4/12 py-4">
                        <div class="quick-box flex items-center">
                            <img src="@/assets/arrow.png" alt="arrow">
                            <a href="" class="ml-3">Secretaría del Acuerdo de Escazú</a>
                        </div>
                    </div>
                    <div class="w-4/12 py-4">
                        <div class="quick-box flex items-center">
                            <img src="@/assets/arrow.png" alt="arrow">
                            <a href="" class="ml-3">Recursos multimedia y otros materiales</a>
                        </div>
                    </div>
                    <div class="w-4/12 py-4">
                        <div class="quick-box flex items-center">
                            <img src="@/assets/arrow.png" alt="arrow">
                            <a href="" class="ml-3">Secretaría del Acuerdo de Escazú</a>
                        </div>
                    </div>
                    <div class="w-4/12 py-4">
                        <div class="quick-box flex items-center">
                            <img src="@/assets/arrow.png" alt="arrow">
                            <a href="" class="ml-3">Secretaría del Acuerdo de Escazú</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
        <div class="flex">
            <div class="w-8/12">
                <PostContent/>
            </div>
            <div class="w-4/12"></div>
        </div>
        </div>
    </div>
</template>

<style>
.page-content{
    background: #E6E6E6;
}
.quick-access{
    background: #fff;
    border-radius: 10px;
}
.quick-access h1{
    font-family: "Public Sans",sans-serif;
    font-size: 32px;
    font-weight: 700;
    line-height: 37.6px;
    text-align: left;
    color: #141E0C;
}
.quick-access a{
    font-family: "Public Sans",sans-serif;
    font-size: 17px;
    font-weight: 700;
    line-height: 37.6px;
    text-align: left;
    color: #4F5DA3;
    text-decoration: underline;
}

</style>

<script>
    import PostContent from "@/components/PostContent.vue"
    export default {
        components: {
            PostContent
        }
    }
</script>